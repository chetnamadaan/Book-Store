import React from 'react';
const EditBooks=()=>{
    return(
        <div>EditBooks</div>
    )
}
export default EditBooks