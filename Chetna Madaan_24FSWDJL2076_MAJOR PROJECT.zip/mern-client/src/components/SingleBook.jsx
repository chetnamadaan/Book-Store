import React from 'react'

const SingleBook = () => {
  return (
    <div>
      Single Book
    </div>
  )
}

export default SingleBook
